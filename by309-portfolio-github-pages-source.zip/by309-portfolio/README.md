# by309 / VSTROY portfolio

Bilingual static portfolio based on v13, with the requested PIC2LUT image changes.

Site: https://misternail.github.io/by309-portfolio/
Russian: https://misternail.github.io/by309-portfolio/ru/

## Build and check

Requires Python 3.12 or newer. No npm dependencies.

    python scripts/build.py
    python scripts/check.py

Content lives in `content/`; templates in `scripts/build.py`; styles and interactions in `dist/assets/`.
GitHub Actions rebuilds, checks and publishes `dist/` after every push to `main`.

For a different hosting URL, update `identity.origin` in `content/site.json` and rebuild.
