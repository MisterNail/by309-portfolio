#!/usr/bin/env python3
"""Check generated pages for broken local links, missing assets and content leaks."""
import json
import re
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
SITE_PREFIX = urlsplit(json.loads((ROOT / "content/site.json").read_text(encoding="utf-8"))["identity"]["origin"]).path.rstrip("/")
errors = []

class Page(HTMLParser):
    def __init__(self, path):
        super().__init__(convert_charrefs=True)
        self.path = path
        self.ids = set()
        self.links = []
        self.assets = []
        self.images = []
        self.h1 = 0
        self.lang = None
        self.description = None
        self.title = False
        self.projects = []
        self.filters = []
        self.alternates = {}
        self.interactive_stack = []
        self.script_type = None
        self.script_data = ""

    def handle_starttag(self, tag, items):
        attrs = dict(items)
        if "id" in attrs:
            if attrs["id"] in self.ids:
                errors.append(f"{self.path}: duplicate id {attrs['id']}")
            self.ids.add(attrs["id"])
        if tag == "html":
            self.lang = attrs.get("lang")
        if tag == "h1":
            self.h1 += 1
        if tag == "title":
            self.title = True
        if tag == "meta" and attrs.get("name") == "description":
            self.description = attrs.get("content")
        if tag == "a":
            self.links.append(attrs.get("href", ""))
            if attrs.get("target") == "_blank" and "noopener" not in attrs.get("rel",""):
                errors.append(f"{self.path}: external target lacks noopener")
        if tag == "link":
            if attrs.get("rel") == "alternate":
                self.alternates[attrs.get("hreflang")] = attrs.get("href")
            if attrs.get("rel") in ("stylesheet","icon","preload"):
                self.assets.append(attrs.get("href",""))
        if tag == "img":
            self.images.append(attrs)
            if attrs.get("src"):
                self.assets.append(attrs["src"])
                if not attrs.get("alt"):
                    errors.append(f"{self.path}: image has no useful alt")
                if not attrs.get("width") or not attrs.get("height"):
                    errors.append(f"{self.path}: image dimensions absent")
        if tag == "script":
            if attrs.get("src"):
                self.assets.append(attrs["src"])
            self.script_type = attrs.get("type")
            self.script_data = ""
        if "data-project" in attrs:
            self.projects.append(attrs)
        if "data-filter" in attrs:
            self.filters.append(attrs["data-filter"])

    def handle_data(self, value):
        if self.script_type == "application/ld+json":
            self.script_data += value

    def handle_endtag(self, tag):
        if tag == "script" and self.script_type == "application/ld+json":
            try:
                json.loads(self.script_data)
            except json.JSONDecodeError:
                errors.append(f"{self.path}: invalid structured data")
            self.script_type = None

pages = {}
for path in sorted(DIST.rglob("*.html")):
    relpath = path.relative_to(DIST).as_posix()
    parser = Page(relpath)
    text = path.read_text(encoding="utf-8")
    parser.feed(text)
    pages[relpath] = parser
    if parser.lang not in ("en","ru") or parser.h1 != 1 or not parser.title or not parser.description:
        errors.append(f"{relpath}: language, h1, title or description missing")
    forbidden = [
        "zaharka.by309", "Nastya_Mati@",
        "github.com/by309/MIKL-PRO", "github.com/by309/big-tech",
        "github.com/by309/cloude-collection", "github.com/Nastya-Mati/",
        "github.com/by309/telegram-research-desk", "57 million",
        "57 миллионов", "photo_13@", "photo_14@", "photo_15@",
        "TODO", "lorem ipsum"
    ]
    for value in forbidden:
        if value.lower() in text.lower():
            errors.append(f"{relpath}: forbidden placeholder/private reference {value}")

for name, page in pages.items():
    for url in page.links + page.assets:
        parsed = urlsplit(url)
        if parsed.scheme in ("https","http","mailto","tel"):
            if url in page.assets and url != "https://media1.tenor.com/m/Tu9H1UiziEQAAAAC/tf2-team-fortress-2.gif":
                errors.append(f"{name}: unexpected external asset {url}")
            continue
        if url == "#" or not url:
            errors.append(f"{name}: empty link")
            continue
        if parsed.path.startswith("/"):
            local_path = unquote(parsed.path)
            if SITE_PREFIX and local_path.startswith(SITE_PREFIX + "/"):
                local_path = local_path[len(SITE_PREFIX):]
            target = DIST / local_path.lstrip("/")
        else:
            target = (DIST / name).parent / unquote(parsed.path) if parsed.path else DIST / name
        target = target.resolve()
        try:
            targetname = target.relative_to(DIST).as_posix()
        except ValueError:
            errors.append(f"{name}: path escapes static directory: {url}")
            continue
        if not target.exists():
            errors.append(f"{name}: missing local target {url}")
        if parsed.fragment and targetname in pages and parsed.fragment not in pages[targetname].ids:
            errors.append(f"{name}: missing fragment {url}")
    if name != "404.html" and not {"en","ru","x-default"}.issubset(page.alternates):
        errors.append(f"{name}: incomplete language alternates")

for home in ("index.html","ru/index.html"):
    page = pages[home]
    if len(page.projects) != 8 or len(page.filters) != 4:
        errors.append(f"{home}: expected eight projects and four filters")
    counts = {cat: sum(p.get("data-category") == cat for p in page.projects) for cat in ("engineering","software","ai")}
    if counts != {"engineering":2,"software":4,"ai":2}:
        errors.append(f"{home}: incorrect category membership {counts}")

projects = json.loads((ROOT/"content/projects.json").read_text(encoding="utf-8"))
if len(pages) != 19:
    errors.append(f"Expected 19 HTML pages, found {len(pages)}")
for project in projects:
    for key in ("title","summary","kicker","status"):
        if not all(project[key].get(lang) for lang in ("en","ru")):
            errors.append(f"{project['id']}: missing localized {key}")
    for section in ("problem","approach","outcome","boundary"):
        if not all(project["caseStudy"][section].get(lang) for lang in ("en","ru")):
            errors.append(f"{project['id']}: missing case text {section}")

ElementTree.parse(DIST/"sitemap.xml")
css = (DIST/"assets/style.css").read_text()
if "prefers-reduced-motion" not in css or ":focus-visible" not in css or "[hidden]" not in css:
    errors.append("CSS lacks a motion, focus or hidden-state safeguard")
if "fetch(" in (DIST/"assets/site.js").read_text():
    errors.append("Unexpected network dependency in client JavaScript")

def luminance(hexcode):
    values=[int(hexcode[i:i+2],16)/255 for i in (0,2,4)]
    rgb=[v/12.92 if v <= .04045 else ((v+.055)/1.055)**2.4 for v in values]
    return sum(a*b for a,b in zip(rgb,[.2126,.7152,.0722]))

colors={"body":"f1f1e9","muted":"b2b6a9","quiet":"92998a","yellow":"dfed75","violet":"bcafdb","cyan":"9dcac6"}
for label,color in colors.items():
    for background in ("121411","1b1e19"):
        ratio=(luminance(color)+.05)/(luminance(background)+.05)
        if ratio<4.5:
            errors.append(f"{label} contrast {ratio:.2f} on {background} is below 4.5")

if errors:
    print("\n".join(errors))
    raise SystemExit(1)
assets=sum(p.stat().st_size for p in (DIST/"assets").iterdir() if p.is_file())
print(f"PASS: {len(pages)} pages; local links, fragments, images, EN/RU routes, structured data and eight-project filters.")
print(f"PASS: portfolio content checks, one requested remote GIF, no client requests; core text contrast ≥ 4.5:1.")
print(f"Static assets: {assets/1024:.0f} KiB total. Browser layout and interactive QA remain unverified in this environment.")
