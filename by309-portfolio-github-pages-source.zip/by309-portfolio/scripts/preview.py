#!/usr/bin/env python3
"""Build a self-contained bilingual preview using the original v13 shell."""
from pathlib import Path
import base64,json,mimetypes,posixpath,re
ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist'
SHELL_PREFIX='<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>by309 — исправлены две фразы</title><style>html,body{width:100%;height:100%;margin:0;overflow:hidden;background:#121411}iframe{display:block;border:0;width:100%;height:100%}</style></head><body><iframe id="site" title="by309 portfolio"></iframe><script>\nconst PAGES='
SHELL_SUFFIX=";const f=document.getElementById('site');let pendingHash='';function parseRoute(){const h=location.hash.slice(1);const q=h.startsWith('/page/')?h.slice(6):'ru/index.html';const idx=q.indexOf('~');return [idx<0?q:q.slice(0,idx),idx<0?'':decodeURIComponent(q.slice(idx+1))]}function load(page,hash){if(!Object.hasOwn(PAGES,page))page='index.html';pendingHash=hash||'';f.srcdoc=PAGES[page];}f.addEventListener('load',()=>{if(pendingHash){const h=pendingHash.slice(1),target=f.contentDocument&&f.contentDocument.getElementById(decodeURIComponent(h));if(target)target.scrollIntoView();pendingHash='';}});window.addEventListener('message',e=>{if(e.source!==f.contentWindow||e.data?.type!=='portfolio-preview-nav')return;const p=e.data.page;if(!Object.hasOwn(PAGES,p))return;const hash=e.data.hash||'';const href='#/page/'+p+(hash?'~'+encodeURIComponent(hash):'');if(location.hash===href)load(p,hash);else location.hash=href;});window.addEventListener('hashchange',()=>load(...parseRoute()));load(...parseRoute());\n</script></body></html>"
NAV='<script>(function(){const current="ru/index.html";document.addEventListener(\'click\',function(e){const a=e.target.closest(\'a[href]\');if(!a)return;if(e.ctrlKey||e.metaKey||e.altKey||e.shiftKey||a.hasAttribute(\'data-lightbox\'))return;const href=a.getAttribute(\'href\');if(!href||href.startsWith(\'#\')||/^(https?:|mailto:|tel:|data:)/i.test(href))return;const url=new URL(href,\'https://preview.local/\'+current);if(url.origin!==\'https://preview.local\')return;e.preventDefault();parent.postMessage({type:\'portfolio-preview-nav\',page:url.pathname.slice(1),hash:url.hash},\'*\');},true);})();</script>'

def build_preview(output):
    pages={}
    for path in sorted(DIST.rglob('*.html')):
        page=path.relative_to(DIST).as_posix()
        text=path.read_text(encoding='utf-8')
        css=(DIST/'assets/style.css').read_text(encoding='utf-8')
        js=(DIST/'assets/site.js').read_text(encoding='utf-8')
        text=re.sub(r'<link[^>]+rel="stylesheet"[^>]*>',lambda m:'<style>'+css+'</style>',text)
        text=re.sub(r'<script[^>]+src="[^"]*assets/site.js"[^>]*></script>',lambda m:'<script>'+js+'</script>',text)
        for asset in (DIST/'assets').iterdir():
            if asset.suffix in ('.css','.js'): continue
            relative=posixpath.relpath('assets/'+asset.name,posixpath.dirname(page) or '.')
            mime={'.webp':'image/webp','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.gif':'image/gif'}.get(asset.suffix) or mimetypes.guess_type(asset.name)[0] or 'application/octet-stream'
            uri='data:'+mime+';base64,'+base64.b64encode(asset.read_bytes()).decode('ascii')
            text=text.replace(relative,uri)
        nav=re.sub(r'const current="[^"]*"',lambda m:'const current='+json.dumps(page),NAV)
        pages[page]=text.replace('</body>',nav+'</body>')
    payload=json.dumps(pages,ensure_ascii=True,separators=(',',':')).replace('<',r'<')
    Path(output).write_text(SHELL_PREFIX+payload+SHELL_SUFFIX,encoding='utf-8')
    print(f'Built standalone preview: {len(pages)} pages')
if __name__=='__main__':
    import sys
    build_preview(sys.argv[1] if len(sys.argv)>1 else ROOT/'preview.html')
