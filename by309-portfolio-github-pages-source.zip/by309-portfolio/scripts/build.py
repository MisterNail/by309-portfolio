#!/usr/bin/env python3
"""Build the static bilingual portfolio. Standard library only."""
import json
import re
from html import escape
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
CONFIG = json.loads((ROOT / "content/site.json").read_text(encoding="utf-8"))
PROJECTS = json.loads((ROOT / "content/projects.json").read_text(encoding="utf-8"))
if isinstance(PROJECTS, dict):
    PROJECTS = PROJECTS["projects"]
ASSETS = json.loads((ROOT / "content/assets.json").read_text(encoding="utf-8"))
IDENTITY = CONFIG["identity"]
ORIGIN = IDENTITY["origin"].rstrip("/")
BY_ID = {p["id"]: p for p in PROJECTS}
# Existing project categories, kept together in the common card grid.
# Engineering (2), Apps & tools (4), Applied AI (2).
CARD_ORDER = ["pcb2cad", "pattern-engine", "cloudex", "telegram-research-desk", "neyronotes", "fastcheck", "plm-assistant", "mikl-pro"]
ARROW = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14" stroke="currentColor" stroke-width="1.5"/></svg>'
DOWN = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 4v16m-7-7 7 7 7-7" stroke="currentColor" stroke-width="1.5"/></svg>'
LEFT = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 12H4m7-7-7 7 7 7" stroke="currentColor" stroke-width="1.5"/></svg>'
RIGHT = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 12h16m-7-7 7 7-7 7" stroke="currentColor" stroke-width="1.5"/></svg>'

def e(value):
    return escape(str(value), quote=True)

def tx(value, lang):
    return value[lang] if isinstance(value, dict) else value

def route(lang, project=None):
    prefix = "ru/" if lang == "ru" else ""
    return prefix + (f"projects/{project}/index.html" if project else "index.html")

def rel(page, target):
    import posixpath
    if page == "404.html":
        return urlsplit(ORIGIN).path.rstrip("/") + "/" + target
    return posixpath.relpath(target, posixpath.dirname(page) or ".")

def asset(page, name):
    return rel(page, "assets/" + name)

def pic(page, name, alt, classes="", eager=False):
    dimensions = ASSETS[name]
    return f'<img src="{asset(page, name)}" width="{dimensions["width"]}" height="{dimensions["height"]}" alt="{e(alt)}" class="{e(classes)}" loading="{"eager" if eager else "lazy"}" decoding="async"{" fetchpriority=\"high\"" if eager else ""}>'

def href(page, lang, section=None):
    return rel(page, route(lang)) + (f"#{section}" if section else "")

def header(page, lang, project=None, special=None):
    t = CONFIG[lang]
    other = "ru" if lang == "en" else "en"
    alternate = route(other, project) if not special else ("ru/" if other == "ru" else "") + special
    nav = "".join(f'<a href="{href(page, lang, target)}">{e(t[label])}</a>' for target, label in [("work","navWork"),("about","navAbout"),("approach","navApproach")])
    languages = f'<div class="languages" aria-label="{"Language" if lang == "en" else "Язык"}"><a href="{rel(page, route("en",project) if not special else special)}" lang="en" hreflang="en"{" aria-current=\"page\"" if lang == "en" else ""}>EN</a><span aria-hidden="true">/</span><a href="{rel(page, route("ru",project) if not special else "ru/"+special)}" lang="ru" hreflang="ru"{" aria-current=\"page\"" if lang == "ru" else ""}>RU</a></div>'
    return f'''<a class="skip-link" href="#main">{e(t["skip"])}</a>
<header class="site-header" id="top"><div class="header-inner shell">
  <a href="{href(page,lang)}" class="wordmark" aria-label="by309 — {"home" if lang == "en" else "главная"}">by<span>309</span><i aria-hidden="true"></i></a>
  <span class="header-role">{e(t["role"])}</span>
  <nav class="desktop-nav" aria-label="{"Main" if lang == "en" else "Основная"}">{nav}</nav>
  {languages}
  <a class="header-contact" href="{href(page,lang,"contact")}">{e(t["navContact"])}{ARROW}</a>
  <details class="mobile-nav"><summary aria-label="{e(t["menu"])}"><span></span><span></span></summary><nav aria-label="{"Mobile" if lang == "en" else "Мобильная"}">{nav}<a href="{href(page,lang,"contact")}">{e(t["navContact"])}</a></nav></details>
</div></header>'''

def footer(page,lang):
    t=CONFIG[lang]
    return f'''<footer class="site-footer shell"><a class="wordmark footer-wordmark" href="{href(page,lang)}">by<span>309</span><i aria-hidden="true"></i></a><p>© 2026<br><span>{e(t["footer"])}</span></p></footer>'''

def contact(page,lang,compact=False):
    t=CONFIG[lang]
    return f'''<section id="contact" class="contact-section shell{" compact-contact" if compact else ""}" aria-labelledby="contact-heading">
  <div class="contact-layout"><div><h2 id="contact-heading">{t["contactTitle"]}</h2><p>{e(t["contactBody"])}</p></div>
  <div class="contact-links"><a href="{IDENTITY["telegram"]}" target="_blank" rel="noopener noreferrer"><div><span>{e(t["telegramLabel"])}</span><small>{e(t["telegramDetail"])}</small></div>{ARROW}</a><a href="{IDENTITY["github"]}" target="_blank" rel="noopener noreferrer"><div><span>{e(t["githubLabel"])}</span><small>{e(t["githubDetail"])}</small></div>{ARROW}</a><a href="https://t.me/by309" target="_blank" rel="noopener noreferrer"><div><span>@by309</span><small>Telegram</small></div>{ARROW}</a></div></div>
</section>'''

def layout(page,lang,title,description,body,project=None,special=None,og=None):
    t=CONFIG[lang]
    other="ru" if lang=="en" else "en"
    alternate=route(other,project) if special is None else ("ru/" if other=="ru" else "")+special
    canonical=ORIGIN+"/"+page
    ogimage=ORIGIN+"/assets/share.jpg"
    structured={"@context":"https://schema.org","@type":"Person","name":"by309","url":ORIGIN,"sameAs":[IDENTITY["github"],IDENTITY["telegram"]],"description":t["description"]}
    if project:
        p=BY_ID[project]
        structured={"@context":"https://schema.org","@type":"CreativeWork","name":tx(p["title"],lang),"description":tx(p["summary"],lang),"url":canonical,"inLanguage":lang}
        if project != "neyronotes":
            structured["creator"]={"@type":"Person","name":"by309"}
    return f'''<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="dark">
<meta name="theme-color" content="#121411">
<title>{e(title)}</title>
<meta name="description" content="{e(description)}">
<meta property="og:type" content="{"article" if project else "website"}">
<meta property="og:title" content="{e(title)}">
<meta property="og:description" content="{e(description)}">
<meta property="og:url" content="{canonical}">
<meta property="og:image" content="{ogimage}">
<meta property="og:image:width" content="1280">
<meta property="og:image:height" content="720">
<meta property="og:image:alt" content="PIC2LUT: a physical circuit board and its recovered CAD layout">
<meta property="og:locale" content="{"ru_RU" if lang=="ru" else "en_US"}">
<meta name="twitter:card" content="summary_large_image">
<link rel="canonical" href="{canonical}">
<link rel="alternate" hreflang="{other}" href="{ORIGIN}/{alternate}">
<link rel="alternate" hreflang="{lang}" href="{canonical}">
<link rel="alternate" hreflang="x-default" href="{ORIGIN}/{route("en",project) if special is None else special}">
<link rel="icon" href="{asset(page,"favicon.svg")}" type="image/svg+xml">
<link rel="stylesheet" href="{asset(page,"style.css")}">
<script src="{asset(page,"site.js")}" defer></script>
<script type="application/ld+json">{json.dumps(structured,ensure_ascii=False).replace("</","<\\/")}</script>
</head>
<body class="{"case-page" if project else "home-page"}">
{header(page,lang,project,special)}
<main id="main">{body}</main>
{footer(page,lang)}
<dialog id="image-viewer" aria-label="{e(t["gallery"])}"><form method="dialog"><button class="viewer-close" aria-label="{e(t["closeImage"])}">×</button></form><img alt=""><p></p></dialog>
</body>
</html>'''

def project_card(page,lang,p,idx):
    title=tx(p["title"],lang)
    image=p["images"][0] if p.get("images") else None
    media=""
    if p["id"]=="neyronotes":
        # Ten individual vertical source panels, displayed three at a time.
        # Keep the requested rotating showcase, but no controls, counters or stitched images.
        groups = [(0,1,2),(2,3,4),(5,6,7),(7,8,9)]
        views = []
        for j,group in enumerate(groups):
            panels = "".join(pic(page,f"neyronotes-panel-{i+1:02}.png",tx(p["images"][2+i]["alt"],lang)) for i in group)
            views.append(f'<div class="neyro-panel-group{" is-active" if j==0 else ""}" aria-hidden="{"false" if j==0 else "true"}">{panels}</div>')
        media=f'<div class="project-media neyronotes-media" data-neyro-carousel><a href="{rel(page,route(lang,p["id"]))}" class="neyro-carousel-view" aria-label="{e(title)}">{"".join(views)}</a></div>'
        return f"""<article class="project-card card-{e(p["id"])}" data-project data-category="{e(p["category"])}">{media}<a href="{rel(page,route(lang,p["id"]))}" class="project-card-link"><div class="project-card-body"><div class="project-title-row"><h3>{e(title)}</h3>{ARROW}</div><p>{e(tx(p["summary"],lang))}</p><div class="tag-list" aria-label="{"Technologies" if lang=="en" else "Особенности"}">{"".join(f"<span>{e(tag)}</span>" for tag in p["tags"][:3])}</div></div></a></article>"""
    if p["id"]=="cloudex":
        media=f'<div class="project-media cloudex-media">{pic(page,"cloudex-mockup-duo.webp",tx(image["alt"],lang))}</div>'
    elif image:
        media=f'<div class="project-media {p["id"]}-media">{pic(page,image["file"],tx(image["alt"],lang))}<span class="image-open" aria-hidden="true">{ARROW}</span></div>'
    else:
        # Reuse the original case-page type banner where no source screenshot exists.
        media=f'<div class="project-media case-type-banner banner-{e(p["id"])} project-placeholder" aria-hidden="true"><span>{e(title)}</span><small>{e(tx(p["kicker"],lang))}</small></div>'
    return f'''<article class="project-card card-{e(p["id"])}" data-project data-category="{e(p["category"])}">
<a href="{rel(page,route(lang,p["id"]))}" class="project-card-link">{media}<div class="project-card-body">
<div class="project-title-row"><h3>{e(title)}</h3>{ARROW}</div><p>{e(tx(p["summary"],lang))}</p>
<div class="tag-list" aria-label="{"Technologies" if lang=="en" else "Технологии"}">{"".join(f"<span>{e(tag)}</span>" for tag in p["tags"][:3])}</div>
</div></a></article>'''

def project_row(page,lang,p,idx):
    return f'''<article class="project-row" data-project data-category="{e(p["category"])}"><a href="{rel(page,route(lang,p["id"]))}"><span class="row-index">{idx:02}</span><div class="row-heading"><h3>{e(tx(p["title"],lang))}</h3><span>{e(tx(p["kicker"],lang))}</span></div><p>{e(tx(p["summary"],lang))}</p><span class="row-status">{e(tx(p["status"],lang))}</span>{ARROW}</a></article>'''



def hero_slideshow(page,lang):
    t = CONFIG[lang]
    slide_ids = ["pattern-engine", "cloudex", "plm-assistant", "telegram-research-desk", "fastcheck"]
    slides = []
    for pid in slide_ids:
        p = BY_ID[pid]
        if not p.get("images"):
            continue
        img = p["images"][0]
        slides.append({
            "href": rel(page, route(lang, pid)),
            "src": asset(page, img["file"]),
            "alt": tx(img["alt"], lang),
            "caption": t["heroPhotoLink"] + " ↗",
            "title": tx(p["title"], lang)
        })
    first = slides[0]
    dimensions = ASSETS[BY_ID[slide_ids[0]]["images"][0]["file"]]
    data = e(json.dumps(slides, ensure_ascii=False))
    return f'<figure class="hero-figure" data-hero-slideshow data-slides="{data}"><a class="hero-image-link" href="{first["href"]}"><img src="{first["src"]}" width="{dimensions["width"]}" height="{dimensions["height"]}" alt="{e(first["alt"])}" class="" loading="eager" decoding="async" fetchpriority="high"><span class="hero-image-arrow" aria-hidden="true">{ARROW}</span></a><figcaption><span class="hero-title-slot"><span class="hero-project-name">{e(first["title"])}</span></span><a href="{first["href"]}">{e(first["caption"])}</a></figcaption></figure>'

def home(lang):
    page=route(lang);t=CONFIG[lang]
    filters="".join(f'<button type="button" data-filter="{key}" aria-pressed="{"true" if key=="all" else "false"}">{e(t[key])}{" <sup>08</sup>" if key=="all" else ""}</button>' for key in ["all","engineering","software","ai"])
    cards="".join(project_card(page,lang,BY_ID[id],i+1) for i,id in enumerate(CARD_ORDER))
    steps="".join(f'<li><span class="step-number">{i+1:02}</span><div><h3>{e(step["title"])}</h3><p>{e(step["text"])}</p></div></li>' for i,step in enumerate(t["steps"]))
    engineer_gif = f'<span class="hero-engineer-gif"><img src="{asset(page,"engineer-guitar.gif")}" width="132" height="75" alt="Инженер играет на гитаре" loading="eager" decoding="async"></span>' if lang == "ru" else ""
    hero_class = "hero shell hero-with-engineer" if lang == "ru" else "hero shell"
    body=f'''<section class="{hero_class}" aria-labelledby="hero-heading">
<div class="hero-copy"><h1 id="hero-heading">{t["heroTitle"]}</h1><p class="hero-description">{e(t["heroDescription"])}</p>{engineer_gif}</div>
{hero_slideshow(page,lang)}
</section>
<section id="work" class="work-section shell" aria-labelledby="work-heading">
<div class="section-heading"><div><h2 id="work-heading">{t["workTitle"]}</h2></div></div>
<div class="filter-bar" data-filter-bar hidden><div class="filter-buttons" role="group" aria-label="{e(t["filterLabel"])}">{filters}</div></div>
<div class="project-grid">{cards}</div>
</section>
<section id="about" class="about-section" aria-labelledby="about-heading"><div class="shell about-layout">
<div class="about-side"><div class="identity-art" aria-hidden="true"><span class="identity-by">by</span><span class="identity-number">309<span class="identity-dot"></span></span></div></div>
<div class="about-copy"><h2 id="about-heading">{t["aboutTitle"]}</h2>{f'<p class="about-subtitle">{e(t["aboutSubtitle"])}</p>' if t.get("aboutSubtitle") else ''}<p>{e(t["aboutBody"])}</p><p>{e(t["aboutBody2"])}</p><div class="studio-note"><p class="eyebrow">{e(t["identityLabel"])}</p><div class="studio-wordmark">{e(t["studioRu"])}<span>VSTROY</span></div><p>{e(t["identityBody"])}</p></div></div>
</div></section>
<section id="approach" class="approach-section shell" aria-labelledby="approach-heading"><div class="section-heading"><div><h2 id="approach-heading">{t["processTitle"]}</h2></div><p class="section-intro">{e(t["processIntro"])}</p></div><ol class="steps">{steps}</ol></section>
{contact(page,lang)}'''
    write(page,layout(page,lang,t["title"],t["description"],body))

def case(lang,p):
    page=route(lang,p["id"]);t=CONFIG[lang]
    gallery=""
    if p["id"]=="neyronotes":
        phone_gallery=""
        panel_gallery=""
        for i,img in enumerate(p.get("images",[])):
            caption=tx(img["caption"],lang)
            if img["file"].startswith("neyronotes-panel-"):
                panel_gallery+=f'<figure class="neyro-detail-panel"><a href="{asset(page,img["file"])}" data-lightbox data-caption="{e(caption)}" aria-label="{e(t["openImage"])}: {e(tx(img["alt"],lang))}">{pic(page,img["file"],tx(img["alt"],lang))}</a></figure>'
            else:
                phone_gallery+=f'<figure class="case-figure"><a href="{asset(page,img["file"])}" data-lightbox data-caption="{e(caption)}" aria-label="{e(t["openImage"])}: {e(tx(img["alt"],lang))}">{pic(page,img["file"],tx(img["alt"],lang),eager=i==0)}<span class="image-open" aria-hidden="true">{ARROW}</span></a><figcaption>{e(caption)}</figcaption></figure>'
        gallery=f'<section class="case-gallery neyronotes-case-gallery" aria-labelledby="gallery-heading"><div class="gallery-heading"><h2 id="gallery-heading">{e(t["gallery"])}</h2><p>{e(t["screenshotNote"])}</p></div><div class="case-gallery-grid">{phone_gallery}</div><div class="neyro-detail-grid">{panel_gallery}</div></section>'
    else:
        for i,img in enumerate(p.get("images",[])):
            caption=tx(img["caption"],lang)
            gallery+=f'<figure class="case-figure{" portrait-figure" if ASSETS[img["file"]]["height"]>ASSETS[img["file"]]["width"] else ""}"><a href="{asset(page,img["file"])}" data-lightbox data-caption="{e(caption)}" aria-label="{e(t["openImage"])}: {e(tx(img["alt"],lang))}">{pic(page,img["file"],tx(img["alt"],lang),eager=i==0)}<span class="image-open" aria-hidden="true">{ARROW}</span></a><figcaption>{e(caption)}</figcaption></figure>'
        if gallery:
            gallery=f'<section class="case-gallery" aria-labelledby="gallery-heading"><div class="gallery-heading"><h2 id="gallery-heading">{e(t["gallery"])}</h2><p>{e(t["screenshotNote"])}</p></div><div class="case-gallery-grid">{gallery}</div></section>'
        else:
            gallery=f'<div class="case-type-banner banner-{e(p["id"])}" aria-hidden="true"><span>{e(tx(p["title"],lang))}</span><small>{e(tx(p["kicker"],lang))}</small></div>'
    source=p.get("source") or {}
    source_link=f'<a class="text-link" href="{e(source["url"])}" target="_blank" rel="noopener noreferrer">{e(t["sourceLabel"])}{ARROW}</a>' if source.get("url") else ""
    case_study=p["caseStudy"]
    caseparts="".join(f'<section class="case-text-section"><span class="eyebrow">0{i+1}</span><div><h2>{e(t[label])}</h2><p>{e(tx(case_study[key],lang))}</p></div></section>' for i,(key,label) in enumerate([("problem","context"),("approach","approach")]))
    current = CARD_ORDER.index(p["id"])
    prev = BY_ID[CARD_ORDER[(current-1) % len(CARD_ORDER)]]
    nxt = BY_ID[CARD_ORDER[(current+1) % len(CARD_ORDER)]]
    prev_name = e(tx(prev["title"],lang))
    next_name = e(tx(nxt["title"],lang))
    prev_note = "Предыдущий проект" if lang == "ru" else "Previous project"
    next_note = "Следующий проект" if lang == "ru" else "Next project"
    previous_link = f'<a class="case-switch-link case-switch-prev" href="{rel(page,route(lang,prev["id"]))}" aria-label="{prev_note}: {prev_name}">{LEFT}<small>{prev_note}</small><span class="case-switch-target">{prev_name}</span></a>'
    next_link = f'<a class="case-switch-link case-switch-next" href="{rel(page,route(lang,nxt["id"]))}" aria-label="{next_note}: {next_name}">{RIGHT}<small>{next_note}</small><span class="case-switch-target">{next_name}</span></a>'
    body=f'''<div class="shell case-shell"><a class="back-link" href="{href(page,lang,"work")}">{LEFT}{e(t["backWork"])}</a>
<header class="case-header"><div class="case-title-row">{previous_link}<h1>{e(tx(p["title"],lang))}</h1>{next_link}</div><p class="case-summary">{e(tx(p["summary"],lang))}</p><div class="case-meta"><div class="tag-list">{"".join(f"<span>{e(tag)}</span>" for tag in p["tags"])}</div></div></header>
{gallery}
<div class="case-details"><aside class="case-aside"><p class="eyebrow">{("Проект коллеги по команде" if lang=="ru" else "A teammate’s project") if p["id"]=="neyronotes" else ("by309 / ВСТРОЙ" if lang=="ru" else "by309 / VSTROY")}</p>{source_link}</aside><div class="case-narrative">{caseparts}</div></div></div>
{contact(page,lang,True)}'''
    write(page,layout(page,lang,tx(p["title"],lang)+" — by309",tx(p["summary"],lang),body,p["id"]))

def write(page,content):
    path=DIST/page;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content,encoding="utf-8")

def main():
    for lang in ("en","ru"):
        home(lang)
        for project in PROJECTS:
            case(lang,project)
    t=CONFIG["en"]
    write("404.html",layout("404.html","en","Page not found — by309",t["pageNotFoundBody"],f'<section class="shell credits-page"><p class="eyebrow">404 / by309</p><h1>{e(t["pageNotFound"])}</h1><p>{e(t["pageNotFoundBody"])}</p><a class="primary-link" href="index.html#work">{e(t["backWork"])}{ARROW}</a></section>'))
    urls=[route(lang) for lang in ("en","ru")]+[route(lang,p["id"]) for lang in ("en","ru") for p in PROJECTS]
    write("sitemap.xml",'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+"".join(f"<url><loc>{e(ORIGIN+'/'+url)}</loc></url>" for url in urls)+"</urlset>\n")
    write("robots.txt","User-agent: *\nAllow: /\nSitemap: "+ORIGIN+"/sitemap.xml\n")
    write(".nojekyll","")
    print(f"Built 2 home pages, {len(PROJECTS)*2} project pages and 404. All content works without JavaScript.")

if __name__=="__main__":
    main()
